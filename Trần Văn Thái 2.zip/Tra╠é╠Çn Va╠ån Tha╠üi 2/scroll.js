const sr = ScrollReveal({
    origin: 'top',
    distance: '60px',
    duration: 2500,
    delay: 400,
}

)
sr.reveal(`.container`)
sr.reveal(`.ads`)
sr.reveal(`.container`)
sr.reveal(`.my-slider`)